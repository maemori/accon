<?php
/**
 * The development database settings. These get merged with the global settings.
 */
return array(
	'active' => 'default',
	'default' => array(
		'type' => 'mysqli',
		'connection' => array(
			'hostname' => '127.0.0.1',
			'port' => '3306',
			'database' => 'accon',
			'username' => 'admin',
			'password' => 'password',
		),
		'identifier' => '`',
		'table_prefix' => '',
		'charset' => 'utf8',
		'collation' => false,
		'enable_cache' => true,
		'profiling' => false,
		'readonly' => array('slave'),
	),
	'slave' => array(
		'type' => 'mysqli',
		'connection' => array(
			'hostname' => '127.0.0.1',
			'port' => '3306',
			'database' => 'accon',
			'username' => 'admin',
			'password' => 'password',
		),
		'identifier' => '`',
		'table_prefix' => '',
		'charset' => 'utf8',
		'collation' => false,
		'enable_cache' => true,
		'profiling' => false,
	),
	'redis' => array(
		'local' => array(
			'hostname' => '127.0.0.1',
			'port' => 6379
		)
	),
);
