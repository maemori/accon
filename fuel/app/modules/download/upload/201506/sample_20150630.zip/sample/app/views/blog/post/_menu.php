<li><a href="/"><span class="glyphicon glyphicon-home"></span>&nbsp;<?php echo MENU_HOME; ?></a></li>
<li class="active"><span class="glyphicon glyphicon-list-alt"></span>&nbsp;Blog</li>
