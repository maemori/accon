<?php
return array(
  'crypto_key' => 'cHAwn0YXoElEj0or_gmJccgM',
  'crypto_iv' => '1iQHCMnmIR_MnB8i78vFkCDs',
  'crypto_hmac' => 'A-QDAQQ5UD1E9iQRzcqEAr0g',
);
