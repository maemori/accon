<div class="container">
	<div class="row">
		<div class="col-md-12">
			<ul class="breadcrumb">
				<li><a href="/"><span class="glyphicon glyphicon-home"></span> <?php echo MENU_HOME; ?></a></li>
			</ul>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<p>はじめに</p>
			<h2>ACCONシリーズ</h2>
			<h3>データベースとアクセス制御を利用したWebアプリケーションに特化し、その開発・実行に必要な基盤をオープンソースとして公開しています。</h3>
			<h4>ACCONシリーズは、OS層からアプリケーション層まで全てをターゲットとしており一貫したWEBアプリケーションのライトな開発・運用を提供します。（従来の5%の労力でアプリケーションを構築&リリースが可能 *1）</h4>
		</div>
	</div>
	<div class="row">
		<div class="col-md-4">
			<h2>おすすめ</h2>
			<ul class="list-group">
				<li class="list-group-item">
					<div class="text-left"><span title="Menu" class="glyphicon glyphicon-ok-sign"></span>&nbsp;Acconモジュール<span>&nbsp;・・・&nbsp;基礎モジュール</span>
						<ul class="list-group">
							<li class="list-group-item">
								<div class="text-left"><a href="/download/view/6"><span title="Menu maker" class="glyphicon glyphicon-ok-sign"></span>&nbsp;ダウンロード</a><span>&nbsp;・・・&nbsp;ACCONモジュールのダウンロード</span>
								</div>
							</li>
							<li class="list-group-item">
								<div class="text-left"><a href="/books/book/manual/accon/"><span title="Menu maker" class="glyphicon glyphicon-ok-sign"></span>&nbsp;マニュアル</a><span>&nbsp;・・・&nbsp;インストール方法、概要、利用方法など</span>
								</div>
							</li>
						</ul>
					</div>
				</li>
				<li class="list-group-item">
					<div class="text-left"><span title="Menu" class="glyphicon glyphicon-ok-sign"></span>&nbsp;Menus<span>&nbsp;・・・&nbsp;メニュー管理アプリケーション</span>
						<ul class="list-group">
							<li class="list-group-item">
								<div class="text-left"><a href="/download/view/13"><span title="Menu maker" class="glyphicon glyphicon-ok-sign"></span>&nbsp;ダウンロード</a><span>&nbsp;・・・&nbsp;Menusモジュールのダウンロード</span>
								</div>
							</li>
							<li class="list-group-item">
								<div class="text-left"><a href="/books/book/manual/menus/"><span title="Menu maker" class="glyphicon glyphicon-ok-sign"></span>&nbsp;マニュアル</a><span>&nbsp;・・・&nbsp;インストール方法、概要、利用方法など</span>
								</div>
							</li>
						</ul>
					</div>
				</li>
				<li class="list-group-item">
					<div class="text-left"><span title="Menu" class="glyphicon glyphicon-ok-sign"></span>&nbsp;Books<span>&nbsp;・・・&nbsp;ツリー構造のコンテンツを管理するアプリケーション</span>
						<ul class="list-group">
							<li class="list-group-item">
								<div class="text-left"><a href="/download/view/14"><span title="Menu maker" class="glyphicon glyphicon-ok-sign"></span>&nbsp;ダウンロード</a><span>&nbsp;・・・&nbsp;Booksモジュールのダウンロード</span>
								</div>
							</li>
							<li class="list-group-item">
								<div class="text-left"><a href="/books/book/manual/books/"><span title="Menu maker" class="glyphicon glyphicon-ok-sign"></span>&nbsp;マニュアル</a><span>&nbsp;・・・&nbsp;インストール方法、概要、利用方法など</span>
								</div>
							</li>
						</ul>
					</div>
				</li>
				<li class="list-group-item">
					<div class="text-left"><span title="Menu" class="glyphicon glyphicon-ok-sign"></span>&nbsp;Download<span>&nbsp;・・・&nbsp;ダウンロードサービスを管理するアプリケーション</span>
						<ul class="list-group">
							<li class="list-group-item">
								<div class="text-left"><a href="/download/view/7"><span title="Menu maker" class="glyphicon glyphicon-ok-sign"></span>&nbsp;ダウンロード</a><span>&nbsp;・・・&nbsp;Downloadモジュールのダウンロード</span>
								</div>
							</li>
							<li class="list-group-item">
								<div class="text-left"><a href="/books/book/manual/download/"><span title="Menu maker" class="glyphicon glyphicon-ok-sign"></span>&nbsp;マニュアル</a><span>&nbsp;・・・&nbsp;インストール方法、概要、利用方法など</span>
								</div>
							</li>
						</ul>
					</div>
				</li>
			</ul>
			<?php echo render('layout/rectangle'); ?>
		</div>
		<div class="col-md-8">
			<h2>連絡</h2>
			<?php echo render('blog/front/_list'); ?>
			<div class="pull-right"><?php echo Pagination::instance('pagination')->render(); ?></div>
			<p>*1 開発対象の特性、外的要因、開発者の熟練度により変動します</p>
		</div>
	</div>
</div>
